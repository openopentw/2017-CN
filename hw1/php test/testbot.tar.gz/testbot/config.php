<?php
$channel = '#CN_Demo';
$channel_pass = 'ILoveTA';
$nick = 'php_bot';
$server = 'irc.freenode.net';
$port = 6667;
$testdata_fn = 'testdata.txt';
$target = 'b04902023';
?>
