import socket
import time


def check(m):
    l = len(m);
    b = m[0];
    try:
        m = int(m);
        if l > 1 and b == '0':
            return False;
        elif m >= 0 and m <= 255:
            return True;
        return False;
    except:
        return False


# Config
server = 'irc.freenode.net';
port = 6667;
nick = 'chia7_Robot';


# Read in Channel
f = open('config', 'r');
channel = f.readline().split("'")[1];
f.close()
PRIVMSG = 'PRIVMSG '+channel+' :';


# Connect to Server
IRCSocket = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
IRCSocket.connect( (server, port) )


IRCSocket.send( bytes('User chia7 chia7 chia7 chia7\r\n', encoding='utf8') )
IRCSocket.send( bytes('NICK '+nick+'\r\n', encoding='utf8') )
IRCSocket.send( bytes('JOIN '+channel+'\r\n', encoding='utf8') )
IRCSocket.send( bytes(PRIVMSG+'Hello! I am robot.\r\n', encoding='utf8') )

while True:
    IRCMsg = IRCSocket.recv(4096).decode()
    if IRCMsg[:6] == 'PING :':
        IRCSocket.send( bytes('PONG '+IRCMsg.split()[1], encoding='utf8') );
    else:
        IRCMsg = IRCMsg.split(PRIVMSG);
        if len(IRCMsg) > 1:
            IRCMsg = IRCMsg[1].strip();
            index = IRCMsg.find(' ')
            cmd = IRCMsg[:index]
            content = IRCMsg[index:].strip()
        
            if cmd == '@repeat':
                IRCSocket.send( bytes(PRIVMSG+content+'\r\n', encoding='utf8') );
            elif cmd == '@convert':
                if content[:2] == '0x':
                    try:
                        IRCSocket.send( bytes(PRIVMSG+str(int(content, 16))+'\r\n', encoding='utf8') );
                    except:
                        pass
                else:
                    try:
                        IRCSocket.send( bytes(PRIVMSG+hex(int(content))+'\r\n', encoding='utf8') );
                    except:
                        pass    
            elif cmd == '@ip':
                l = len(content);
                arr = [];
            
                if l < 4 or l > 12:
                    IRCSocket.send( bytes(PRIVMSG+'0\r\n', encoding='utf8') );
                else:
                    for i in range(1,4):
                        for j in range(1,4):
                            for k in range(1,4):
                                r = l-i-j-k;
                                if r > 0 and r < 4:
                                    if check(content[:i]) and check(content[i:i+j]) and check(content[i+j:i+j+k]) and check(content[i+j+k:]):
                                        arr.append(content[:i]+'.'+content[i:i+j]+'.'+content[i+j:i+j+k]+'.'+content[i+j+k:]);
                
                    IRCSocket.send( bytes(PRIVMSG+str(len(arr))+'\r\n', encoding='utf8') );
                    for ip in arr:
                        IRCSocket.send( bytes(PRIVMSG+ip+'\r\n', encoding='utf8') );
                        time.sleep(1);
            elif IRCMsg == '@help':
                IRCSocket.send( bytes(PRIVMSG+'@repeat <Message>\r\n', encoding='utf8') );
                IRCSocket.send( bytes(PRIVMSG+'@convert <Number>\r\n', encoding='utf8') );
                IRCSocket.send( bytes(PRIVMSG+'@ip <String>\r\n', encoding='utf8') );
