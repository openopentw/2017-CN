import socket
import time
import random 

class Robot:
	def __init__(self, nickname="MMRO8OTO", channel="#CN_Demo", server="irc.freenode.net", port=6667):
		self.nickname = nickname
		self.channel = channel
		self.server = server
		self.port = port

	def connect(self):
		self.Client = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
		self.Client.connect((self.server, self.port))

	def set_user(self):
		# USER <username> <hostname> <servername> <realname>
		msg = "USER {} {} {} {}\r\n".format(self.nickname, self.nickname, self.nickname, self.nickname)
		self.Client.send(msg)

	def set_nickname(self):
		# NICK <nickname>
		msg = "NICK {}\r\n".format(self.nickname)
		self.Client.send(msg)

	def join_ch(self):
		# JOIN <channels>
		msg = "JOIN {}\r\n".format(self.channel)
		self.Client.send(msg)

	def talk(self, message):
		# PRIVMSG <msgtarget> <message>
		msg = "PRIVMSG {} :{}\r\n".format(self.channel, message)
		self.Client.send(msg)

	def pong(self):
		# PONG <server>
		msg = "PONG {}\r\n".format(self.server)
		self.Client.send(msg)

	def combination(self, m, s):
		if m == 0: return [[]]
		if s == []: return []
		return [s[:1] + a for a in self.combination(m-1, s[1:])] + self.combination(m, s[1:])

	def ip(self, message):
		length = len(message)
		comb = self.combination(3, range(length)[1::])
		ips = set()
		for i in comb:
			# print message[:i[0]], message[i[0]:i[1]], message[i[1]:i[2]], message[i[2]:]
			tmp = []
			if len(message[:i[0]]) > 0 and len(message[:i[0]]) < 4 and int(message[:i[0]]) < 256:
				if len(message[:i[0]])>1 and message[:i[0]][0] == '0':
					continue
				tmp += [str(int(message[:i[0]]))]
			else: continue;
			if len(message[i[0]:i[1]]) > 0 and len(message[i[0]:i[1]]) < 4 and int(message[i[0]:i[1]]) < 256:
				if len(message[i[0]:i[1]])>1 and message[i[0]:i[1]][0] == '0':
					continue
				tmp += [str(int(message[i[0]:i[1]]))]
			else: continue;
			if len(message[i[1]:i[2]]) > 0 and len(message[i[1]:i[2]]) < 4 and int(message[i[1]:i[2]]) < 256:
				if len(message[i[1]:i[2]])>1 and message[i[1]:i[2]][0] == '0':
					continue
				tmp += [str(int(message[i[1]:i[2]]))]
			else: continue;
			if len(message[i[2]:]) > 0 and len(message[i[2]:]) < 4 and int(message[i[2]:]) < 256:
				if len(message[i[2]:])>1 and message[i[2]:][0] == '0':
					continue
				tmp += [str(int(message[i[2]:]))]
			else: continue;
			# print tmp
			ips.add(".".join(tmp))
		return ips

	def invalid(self):
		msg = "invalid input!"
		self.talk(msg)

	def get_res(self, num=4096):
		recv = self.Client.recv(num)
		res = recv.split()
		if res[0] == "PING":
			self.pong()
			self.talk("got pinged")

		if res[1] == "PRIVMSG":
			cmd = res[3][1:]
			if cmd == "@help":
				if len(res) < 5:
					msg = "@repeat <Message>"
					self.talk(msg)
					msg = "@convert <Number>"
					self.talk(msg)
					msg = "@ip <String>"
					self.talk(msg)

			if cmd == "@repeat":
				tmp = recv.find("@repeat")
				msg = recv[tmp+8::].lstrip()
				self.talk(msg)

			if cmd == "@convert":
				h = "0123456789abcdef"
				d = "0123456789"
				if len(res) < 5:
					msg = "Please input Number!"
					self.talk(msg)
					return recv

				msg = res[4]
				if msg[0:2] == "0x" and len([a for a in msg[2:] if a not in h])==0 and len(msg)>2:
					self.talk(int(msg, 16))
				elif len([a for a in msg if a not in d])==0:
					self.talk(hex(int(msg)))
				else:
					self.invalid()

			if cmd == "@ip":
				if len(res) < 5:
					msg = "Please input String!"
					self.talk(msg)
					return recv

				d = "0123456789"
				msg = res[4]
				if len([a for a in msg if a not in d])>0:
					self.invalid()
					return recv
				
				ips = self.ip(msg)
				self.talk(len(ips))
				for j,i in enumerate(ips):
					time.sleep(random.random()+0.5)
					print "{}.\t{}".format(j,i)
					self.talk(i)

		return recv

f = open("config").read()
f = f.split('=')
channel = f[1][1:-1]
Client = Robot(channel=channel)
Client.connect()
Client.set_user()
Client.set_nickname()
Client.join_ch()
instruction = "Hello! I am robot."
Client.talk(instruction)

while True:
	msg = Client.get_res(4096)
	print msg
